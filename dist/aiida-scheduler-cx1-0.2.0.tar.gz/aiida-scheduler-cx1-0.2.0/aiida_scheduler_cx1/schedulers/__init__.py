"""
Parsers provided by the plugin

Register parsers via the "aiida.parsers" entry point in setup.json.
"""
