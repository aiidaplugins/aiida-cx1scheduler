"""
AiiDA Plugin Template

Adapt this template for your own needs.
"""

__version__ = "0.2.0"
